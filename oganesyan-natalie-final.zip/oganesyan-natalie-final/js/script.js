/* script.js 
   Author:
   Date:
*/

$(document).ready(function(){ // begin document.ready block

//BREADBOXES

	$('.bakedbread').click(function(){
		$('.barbariafter').show();
		$('.barbaribefore').hide();
		$('.barbariafter').append('Bread baked!').css({'font-size': '1.5em'});
	});

	$('.bread1').hover(function(){
		$('.barbaribox h4').fadeIn(200);
		$('.barbaribox p').fadeIn(200);
	});

	$('.bread1').mouseleave(function(){
		$('.barbaribox h4').fadeOut(500);
		$('.barbaribox p').fadeOut(500);
	});

	$('.bakedbread2').click(function(){
		$('.pitaafter').show();
		$('.pitabefore').hide();
		$('.pitaafter').append('Bread baked!').css({'font-size': '1.5em'});
	});

	$('.bread2').hover(function(){
		$('.pitabox h4').fadeIn(200);
		$('.pitabox p').fadeIn(200);
	});

	$('.bread2').mouseleave(function(){
		$('.pitabox h4').fadeOut(500);
		$('.pitabox p').fadeOut(500);
	});

	//SPREADS AND BREADS

	$('.pairings').hover(function(){
		$('.caption', this).slideToggle();
	});

	$('.breads').hover(function(){
		$('.caption', this).slideToggle();
	});

	$('.breadtings').click(function(){
		var pick = $(this).attr('src');
		$('#platebread').attr('src', pick);
		$('.message h1').show();
 	});

	$('.spreads').click(function(){
		var choose = $(this).attr('src');
		$('#platespread').attr('src', choose);
 	});


}); //end document.ready block
